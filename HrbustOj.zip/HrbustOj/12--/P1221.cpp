#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    long long a, b;
    
    while(cin>>a>>b)
    {
    long long flag = 1, base = a;

    while(b != 0)
    {
        if(b & 1 != 0)
            flag = (flag * base) % 10;
        base = (base * base) % 10;

        b >>= 1;
    }

    cout<<flag % 10<<endl;


    }
    // system("pause");
}