#include<bits/stdc++.h>
using namespace std;

int r[] = {0, 5, 6, 7, 18, 1, 2, 3};

int main(void)
{
    int n;
    while(scanf("%d", &n) != EOF)
    {
        cout<<r[n]<<endl;
    }
}
