#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int n;
    while(cin>>n)
    {
        n %= 3;
        n = pow(n, 5);
        n %= 3;
        cout<<n<<endl;
    }
}