#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    cout<<"Get well soon!"<<endl;
}