#include<bits/stdc++.h>
using namespace std;

long long a[4];

int main(void)
{
    while(cin>>a[0]>>a[1]>>a[2])
    {
        sort(a, a + 3);
        cout<<a[1]<<endl;
    }
}