#include<bits/stdc++.h>
using namespace std;

char r[100005];

int main(void)
{
    while(cin>>r)
    {
        if(r[strlen(r) - 1] == '0')
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;
    }
}