#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    cout<<"Jiaozhu87"<<endl;
}