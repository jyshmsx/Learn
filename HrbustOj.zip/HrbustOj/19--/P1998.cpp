#include<iostream>
using namespace std;

struct a{
    char name[22];
    bool d;
}stu[101];

int main(void)
{
    int t;
    while(cin>>t)
    {
        for(int i = 0; i < t; i++)
        {
            cin>>stu[i].name>>stu[i].d;
        }

        for(int i = 0; i < t ; i++)
        {
            if(stu[i].d == false)
            {
                cout<<stu[i].name<<endl;
            }
        }
        cout<<endl;
    }
}