#include<bits/stdc++.h>
using namespace std;

char r[1005];

int main(void)
{
    int n;
    cin>>n;
    while(n--)
    {
        int l;
        cin>>l;
        for(int i = 0; i < l ; i++)
        {
            int y;
            cin>>y;
            if(y >= 90)
                r[i] = 'A';
            else if(y < 90 && y >= 80)
                r[i] = 'B';
            else if(y < 80 && y >= 70)
                r[i] = 'C';
            else if(y < 70 && y >= 60)
                r[i] = 'D';
            else if(y < 60)
                r[i] = 'E';
        }

        for(int i = 0; i < l; i++)
        {
            cout<<r[i]<<" ";
        }
        cout<<endl;

    }

    // system("pause");
}