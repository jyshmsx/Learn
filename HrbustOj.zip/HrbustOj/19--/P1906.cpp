#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int T;
    cin>>T;
    while(T--)
    {
        int n, k;
        cin>>n>>k;

        int cc = 0;
        if(k == 13)
            k = 12;


        cc += n / k;
        
        if(n % k)
        {
            cc++;
            if(n % k == 13)
            {
                if(n > k * (cc - 2) + (k - 1) * 2 || k == 14)
                    cc++;
            }
        }



        cout<<cc<<endl;
        
    }
    // system("pause");
}