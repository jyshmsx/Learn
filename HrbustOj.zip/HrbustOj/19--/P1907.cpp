#include<bits/stdc++.h>
using namespace std;

long long r[4];

int main(void)
{
    while(cin>>r[0]>>r[1]>>r[2])
    {
        sort(r , r + 3);

        cout<<r[1]<<endl;
    }
}