#include<bits/stdc++.h>
using namespace std;

char a[1005];

int main(void)
{
    while(cin.get(a, 1000))
    {
        cin.get();
        int x = 0, k = 0, d = 0;
        for(int i = 0; i < strlen(a); i++)
        {
            if(a[i] >= 'a' && a[i] <= 'z')
                x++;
            else if(a[i] >= 'A' && a[i] <= 'Z')
                d++;
            else if(a[i] == ' ')
                k++;
        }

        
        cout<<x<<" "<<d<<" "<<k<<endl;
    }

}