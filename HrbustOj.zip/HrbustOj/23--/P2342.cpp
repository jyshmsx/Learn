#include<iostream>
#include<cstring>
using namespace std;

char r[1005];

int main(void)
{
    while(cin.get(r, 1000))
    {   
        cin.get();
        int flag = 0;
        for(int i = 0; i < strlen(r); i++)
        {
            
            if(r[i] == 'i')
            {
                i++;
                if(r[i] == 'f')
                {
                    flag++;
                    continue;
                }
                i--;
            }
        }
        cout<<flag<<endl;

    }
}