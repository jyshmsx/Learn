#include<iostream>
#include<cstring>
using namespace std;

char r[15];

int main(void)
{
    while(cin.get(r, 10))
    {
        cin.get();
        bool flag = 1;
        for(int i = 0, j = strlen(r) - 1; ; i++, j--)
        {
            if(r[i] != r[j])
            {
                flag = 0;
                break;
            }

            if(i == j || i == j - 1)
            {
                flag = 1;
                break;
            }
        }
        if(flag)
            cout<<"yes"<<endl;
        else
            cout<<"no"<<endl;
    }
}