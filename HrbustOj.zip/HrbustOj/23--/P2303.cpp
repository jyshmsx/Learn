#include<iostream>
#include<cstring>
using namespace std;

char r[55];

int main(void)
{
    int T;
    cin>>T;
    cin.get();
    while(T--)
    {
        cin.get(r, 50);
        cin.get();

        char re;
        for(int i = 0 ; i < strlen(r); i++)
        {
            if(r[i] >= '0' && r[i] <= '9')
            {
                for(int x = 0; x < r[i] - '0'; x++)
                {
                    cout<<re;
                }
            }
            else
            {
                re = r[i];
                cout<<r[i];
            }
        }

        cout<<endl;

    }
}