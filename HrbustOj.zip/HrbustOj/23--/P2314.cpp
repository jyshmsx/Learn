#include<iostream>
using namespace std;

int main(void)
{
    int T;
    cin>>T;

    while(T--)
    {
        int n;
        cin>>n;
        int up = 0;
        for(int x = 0; x < n; x++)
        {
            int y;
            cin>>y;
            if(y == 1)
                up++;
        }

        printf("%.2lf\n", (double)up / n);
    }

    // system("pause");
}