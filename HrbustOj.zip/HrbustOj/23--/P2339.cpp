#include<iostream>
using namespace std;

int ti[105];

int main(void)
{
    int n, t;
    while(cin>>n>>t)
    {
        for(int x = 1; x <= n; x++)
        {
            int y;
            cin>>y;
            ti[x] = 86400 - y;
        }

        bool flag = 0;
        int i = 1;
        for(i = 1; i <= n; i++)
        {
            t -= ti[i];

            if(t <= 0)
            {
                flag = 1;
                break;
            }
        }
        
        if(flag)
            cout<<i<<endl;
        else
            cout<<"0"<<endl;

    }
}