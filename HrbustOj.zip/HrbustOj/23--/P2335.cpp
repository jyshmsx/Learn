#include<iostream>
using namespace std;

int main(void)
{
    cout<<"8"<<endl;
}