#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int n;
    cin>>n;
    while(n--)
    {
        int x, y;
        cin>>x>>y;
        if(x >= y)
            cout<<"MMM BRAINS"<<endl;
        else
            cout<<"NO BRAINS"<<endl;
    }
}