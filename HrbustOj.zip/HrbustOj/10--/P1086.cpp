#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int n;
    cin>>n;
    while(n--)
    {
        char c;
        while(cin>>c)
        {
            if(c == '.')
                break;
        }
        char s[10];
        cin>>s;
        int l;
        cin>>l;
        if(l <= strlen(s))
            cout<<s[l - 1]<<endl;
        else
            cout<<"0"<<endl;

    }

    // system("pause");
}