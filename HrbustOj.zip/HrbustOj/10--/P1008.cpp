#include<iostream>
#define max 168
using namespace std;

int l[5];

int main(void)
{
    while(cin>>l[0]>>l[1]>>l[2])
    {
        int i;
        bool flag = 1;
        for(i = 0; i < 3; i++)
        {
            if(l[i] <= max)
            {
                flag = 0;
                break;
            }
        }
        
        if(flag)
            cout<<"NO CRASH"<<endl;
        else
            cout<<"CRASH "<<l[i]<<endl;
    }
}