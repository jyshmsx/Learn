#include<bits/stdc++.h>
using namespace std;

struct ma{
    int  cj;
    int jq;
    int rp;
}man[1005];

bool cmp(ma a, ma b)
{
    if(a.cj == b.cj )
    {
        if(a.jq == b.jq)
        {
            return a.rp > b.rp;
        }
        else
            return a.jq > b.jq;
    }
    else
        return a.cj > b.cj;
}


int main(void)
{
    int n;
    while(cin>>n)
    {
        for(int i = 0; i < n; i++)
        {
            cin>>man[i].cj>>man[i].jq>>man[i].rp;
        }


    sort(man, man + n, cmp);

    for(int i =0; i < n; i++)
    {
        cout<<man[i].cj<<" "<<man[i].jq<<" "<<man[i].rp<<endl;
    }
    }
}
