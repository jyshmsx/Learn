#include<iostream>
using namespace std;

int main(void)
{
    int T;
    cin>>T;
    while(T--)
    {
        double v, m;
        cin>>m>>v;
        printf("%.4lf\n", m / v);
    }
    // system("pause");
}