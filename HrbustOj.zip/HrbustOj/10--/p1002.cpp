#include<iostream>
#include<algorithm>
using namespace std;

int r[1005];

bool cmp(int a , int b)
{
    return a > b;
}


int main(void)
{
    int n, m, k, cc= 0;
    while(cin>>n>>m>>k)
    {
        cc++;
        for(int i = 0; i < n * m ; i++)
        {
            cin>>r[i];
        }

        sort(r, r + m*n, cmp);

        cout<<"Scenario #"<<cc<<endl;
        cout<<r[k-1]<<endl<<endl;
    }
}