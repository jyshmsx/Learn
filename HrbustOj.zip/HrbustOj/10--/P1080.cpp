#include<iostream>
using namespace std;

int main(void)
{
    cout<<"JiaoZhuV5"<<endl;
}