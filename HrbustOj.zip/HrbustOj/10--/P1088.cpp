#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int a, b;
    while(cin>>a>>b)
    { 
    printf("%.2lf\n", (double)(a * 0.99 + b * 0.01));
    }
    // system("pause");
}