#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

int r[105][210] = {0};

int maxn(int i, int j)
{
    int m = max(r[i+1][j], r[i+1][j+1]);
    m = max(m, r[i+1][j+2]);

    return m;
}


int main(void)
{
    int T;
    cin>>T;
    while(T--)
    {
        int n;
        cin>>n;
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= 2 * i - 1 ; j++)
            {
                scanf("%d", &r[i][j]);
            }
        }

        for(int i = n - 1; i > 0; i--)
        {
            for(int j = 1; j <= 2 * i - 1; j++)
            {
                r[i][j] += maxn(i, j);
            }
        }

        cout<<r[1][1]<<endl;
    }

    // system("pause");
}
