#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int n;
    cin>>n;
    while(n--)
    {
        int l, t;
        cin>>l>>t;
        l -= 2;
        for(int j = 0; j < t; j++)
        {
            cout<<">+";
            for(int i = 0; i < l ; i++)
            cout<<"-";
            cout<<"+>"<<endl;
        }
    }
    // system("pause");
}