#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int a, b, c;
    while(cin>>a>>b>>c)
    {
        cout<<a+b-c<<endl;
    }
}