#include<bits/stdc++.h>
using namespace std;

int r[1000005];

int main(void)
{
    int n;
    cin>>n;
    for(int i = 0; i < n; i++)
    {
        cin>>r[i];
    }

    sort(r, r + n);

    for(int i = 0; i < n; i++)
    {
        cout<<r[i]<<endl;
    }
}
