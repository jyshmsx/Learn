#include<bits/stdc++.h>
using namespace std;

char r[20];

int main(void)
{
    int n;
    scanf("%d", &n);
    while(n--)
    {
        scanf("%s", &r);
        if(r[strlen(r) - 1] == 'C')
        {
            int c = 0, x = 1;
            for(int i = strlen(r) - 2; i >= 0; i--)
            {
                c += (r[i] - '0') * x;
                x *= 10;
            }
            c =(double)(9 * c / 5)+32;
            cout<<c<<"F"<<endl;
        }
        else if(r[strlen(r) - 1] == 'F')
        {
            int c = 0, x = 1;
            for(int i = strlen(r) - 2; i >= 0; i--)
            {
                c += (r[i] - '0') * x;
                x *= 10;
            }

            c = (double) 5 / 9  * ( c - 32);
            cout<<c<<"C"<<endl;
        }
    }
    // system("pause");
}