#include<iostream>
#include<algorithm>
using namespace std;

int r[105][205];

int main(void)
{
    int n;
    while(cin>>n)
    {
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= i; j++ )
            {
                cin>>r[i][j];
            }
        }

        for(int i = n - 1; i > 0; i--)
        {
            for(int j = 1; j <= i; j++)
            {
                r[i][j] += max(r[i+1][j] , r[i+1][j+1]);
            }
        }

        cout<<r[1][1]<<endl;
    }


}