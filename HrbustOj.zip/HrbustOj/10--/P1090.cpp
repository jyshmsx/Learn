#include<bits/stdc++.h>
using namespace std;

char r[100005];

int main(void)
{
    while(cin>>r)
    {
        int c0 = 0, co = 0;
        for(int i = 0; i < strlen(r); i++)
        {
            if(r[i] == '0')
                c0++;
            else if(r[i] == 'O')
                co++;
        }

        cout<<c0<<" "<<co<<endl;
    }
}