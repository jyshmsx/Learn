#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    string a;
    int n;
    while(cin>>n)
    {
        for(int i = 0; i < n; i++)
        {
            cin>>a;
            cout<<a<<endl;
        }
    }
}