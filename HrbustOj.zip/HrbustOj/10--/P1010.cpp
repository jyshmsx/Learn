#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;

int t[10005];

int main(void)
{
    int n;
    while(cin>>n)
    {
        for(int i = 0; i < n; i++)
        {
            cin>>t[i];
        }

        sort(t, t + n);
        if(n % 2)
        {
            cout<<t[(n - 1)/2]<<endl;
        }
        else
        {
            int pp = (t[n/2] + t[n/2 - 1])/2;
            if( abs(pp - t[n/2]) > abs(pp - t[n/2 - 1]))
            {
                cout<<t[n/2 - 1]<<endl;
            }
            else
            {
                cout<<t[n/2]<<endl;
            }

            
        }
    }

}