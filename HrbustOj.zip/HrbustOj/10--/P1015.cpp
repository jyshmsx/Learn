#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    long long a;
    
    while(cin>>a)
    {
        
        long long c = 0;

        for(int i = 0; i <= a; i++)
        {
            c += i;
        }

        cout<<c<<endl;
    }

    // system("pause");
}