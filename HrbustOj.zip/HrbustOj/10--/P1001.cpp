#include<iostream>
using namespace std;

int main(void)
{
    int n, t = 0;
    while(cin>>n)
    {
        if(n == 0)
            break;
        t++;
        cout<<t<<". ";
        if(n % 2)
            cout<<"odd "<<(n - 1)/2<<endl;
        else    
            cout<<"even "<<n/2<<endl;

    }
    // system("pause");
}