#include<bits/stdc++.h>
using namespace std;

string a;

int main(void)
{
    while(cin>>a)
    {
        if(a == "NO")
            cout<<"YES"<<endl;
        else if(a == "YES")
            cout<<"NO"<<endl;
    }
}