#include<bits/stdc++.h>
using namespace std;

int vv(int fl, int se)
{
    if(fl > 0)
        return fl + se;
    else
        return fl - se;
}

int main(void)
{
    int n;
    while(cin>>n)
    {
        int fl;
        cin>>fl;
        for(int i = 1; i < n; i++)
        {
            int se;
            cin>>se;
            fl = vv(fl, se);
        }

        cout<<fl<<endl;
    }
}