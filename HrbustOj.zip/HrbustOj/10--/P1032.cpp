#include<iostream>
using namespace std;

int main(void)
{
    int n;
    while(cin>>n)
    {
        int c = 1;
        for(int i= 1; i <= n; i++)
            c *= i;

        cout<<c<<endl;
    }
}