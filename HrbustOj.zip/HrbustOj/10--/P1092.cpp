#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int a, b;
    while(scanf("%d %d", &a, &b) != EOF)
    {
        if(a > 0)
            cout<<a+b<<endl;
        else
            cout<<a-b<<endl;
    }
}