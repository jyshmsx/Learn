#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int n;
    cin>>n;
    while(n--)
    {
        int a, b;
        cin>>a>>b;
        cout<<a+b<<endl;
    }
}