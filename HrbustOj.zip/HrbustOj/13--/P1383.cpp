#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    cout<<"Goodbye"<<endl;
}