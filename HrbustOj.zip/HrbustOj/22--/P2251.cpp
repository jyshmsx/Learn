#include<bits/stdc++.h>
using namespace std;

long long a, b;

int main(void)
{
    while(scanf("%lld %lld", &a, &b) != EOF)
    {
        printf("%lld\n", a + b);
    }
}