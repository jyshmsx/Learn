#include<bits/stdc++.h>
using namespace std;

string r;
char a;

int main(void)
{
    int t;
    cin>>t;
    while(t--)
    {
        bool flag = 0;
        for(; ; )
        {
            cin>>a;
            if(a == '.')
                break;
        }
        cin>>r;
        if(r == "cpp")
            cout<<"c++"<<endl;
        else if(r == "c")
            cout<<"c"<<endl;
        else if(r == "java")
            cout<<"java"<<endl;
        else
            cout<<"none"<<endl;

    }

    // system("pause");
}