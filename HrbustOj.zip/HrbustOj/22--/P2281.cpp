#include<bits/stdc++.h>
using namespace std;

char r[30];

int main(void)
{
    while(cin>>r)
    {
        bool flag = 0, jl = 0;
        for(int i = 0; i < strlen(r); i++)
        {
            if(r[i] != 'B' && r[i] != '0')
                break;
            
            if(r[i] == 'B')
                jl = 1;
            

            if(i == strlen(r) - 1)
                flag = 1;
        }

        if(flag && jl)
            cout<<"YES"<<endl;
        else
            cout<<"NO"<<endl;
    }
}