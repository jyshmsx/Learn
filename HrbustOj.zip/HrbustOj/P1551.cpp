#include<bits/stdc++.h>
using namespace std;

char vi[] = {"bkpstor"};
char r[105];


int main(void)
{
    while(cin.get(r, 100))
    {
        cin.get();
        bool flag = 0;
        for(int i = 0; i < strlen(r); i++)
        {
            if(r[i] == vi[0])
            {
                i++;
                for(int j = 1; j < strlen(vi); j++, i++)
                {
                    if(r[i] == vi[j])
                    {
                        if(j == strlen(vi) - 1)
                        {
                            flag = 1;
                        }
                    }
                    else
                    {
                        i--;
                        break;
                    }
                }
            }
            if(flag)
                break;
        }
        if(flag)
                cout<<"Warning"<<endl;
            else
                cout<<"Safe"<<endl;
    }
}