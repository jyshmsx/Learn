#include<bits/stdc++.h>
using namespace std;

unsigned  int a = 1;
int b;

int main(void)
{
    while(cin>>b)
    {
        cout<<b+a<<endl;
    }
}