#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int a, b;
    while(cin>>a>>b)
    {
        cout<<max(a+b,a-b)<<endl;
    }
}