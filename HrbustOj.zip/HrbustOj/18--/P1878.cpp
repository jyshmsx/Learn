#include<bits/stdc++.h>
#include<math.h>
using namespace std;

int main(void)
{
    int a, b, c;
    while(cin>>a>>b>>c)
    {
        if(4 * a * a < b * b + c * c)
            cout<<"NO"<<endl;
        else
            cout<<"YES"<<endl;
    }
}