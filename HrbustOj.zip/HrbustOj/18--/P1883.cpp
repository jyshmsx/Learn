#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int a, b;
    while(cin>>a>>b)
    {
        cout<<a*b<<endl;
    }
}