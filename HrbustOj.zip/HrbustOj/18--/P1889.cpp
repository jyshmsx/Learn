#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int n;
    int t;
    cin>>t;
    while(t--)
    {
        cin>>n;
        int c = 0;
        for(int i = 0; i < n; i++)
        {
            int y;
            cin>>y;
            c += y;
        }
        cout<<c<<endl;
    }
}