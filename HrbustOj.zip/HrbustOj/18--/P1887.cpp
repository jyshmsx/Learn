#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int a, b;
    while(scanf("%d %d", &a, &b) != EOF)
    {
        if(a + b == 0)
            break;
        else
        printf("%d\n", a + b);

    }
}