#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    cout<<"Hello ACM!"<<endl;
}
