#include<bits/stdc++.h>
#define pi 3.14159265358979323846264338328;
using namespace std;

int main(void)
{
    double a, b,s, v;
    while(cin>>a>>b)
    {
        s = b * b * pi;
        v = a * s /3;
        printf("%.2lf\n", v);
    }
}