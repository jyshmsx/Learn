#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int a, b;
    int n;
    cin>>n;
    while(n--)
    {
        scanf("%d %d", &a, &b);
        printf("%d\n", a + b);
    }
}