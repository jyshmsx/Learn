#include<bits/stdc++.h>
using namespace std;

char r[10005];

int main(void)
{
    int n;
    cin>>n;
    cin.get();
    while(n--)
    {
        gets(r);
        int c = 0;
        for(int i = 0; i < strlen(r); i++)
        {
            if((r[i] >= 'a' && r[i] <= 'z') || (r[i] >= 'A' && r[i] <= 'Z'))
            {
                c++;
                for(; i < strlen(r); i++)
                {
                    if(r[i] == ' ')
                        break;
                }
            }
        }
        cout<<c<<endl;
    }

    // system("pause");
}