#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int n;
    bool flag = 0;
    while(cin>>n)
    {
        switch (n){
            case 0:
                {flag = 1;
                break;}
            case 1:
                {cout<<"Accepted"<<endl;
                break;}
            case 2:
                {cout<<"Wrong Answer"<<endl;
                break;}
            case 3:
                {cout<<"Time Limit Exceed"<<endl;
                break;}
            case 4:
                {cout<<"Output Limit Exceed"<<endl;
                break;}
            case 5:
                {cout<<"Memory Limit Exceed"<<endl;
                break;}
            case 6:
                {cout<<"Runtime Error"<<endl;
                break;}
            case 7:
                {cout<<"Presentation Error"<<endl;
                break;}
            case 8:
                {cout<<"Compile Error"<<endl;
                break;}

            
        }

        if(flag)
                break;
    }

    // system("pause");
}