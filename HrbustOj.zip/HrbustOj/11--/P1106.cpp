#include<bits/stdc++.h>
using namespace std;

char r[55];

int main(void)
{
    while(cin>>r)
    {
        int v = 0, g = 0, a = 0;
        for(int i = 0; i < strlen(r); i++)
        {
            if(r[i] == 'v')
                v++;
            else if(r[i] == 'g')
                g++;
            else if(r[i] == 'a')
                a++;
        }

        a /= 3;
        int m = min(a, v);
        m = min(m , g);


        cout<<"THE NUMBER 1S "<<m<<"."<<endl;
    }
}