#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    char a[50];
    while(cin>>a)
    {
        cout<<strlen(a)<<endl;
    }
}