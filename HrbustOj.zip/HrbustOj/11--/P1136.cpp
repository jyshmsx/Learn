#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    double a, b;
    while(cin>>a>>b)
    {
        printf("%.2lf\n", (double)a/b);
    }
}