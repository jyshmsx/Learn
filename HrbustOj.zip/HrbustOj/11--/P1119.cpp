#include<bits/stdc++.h>
using namespace std;

int main(void)
{
    int n;
    while(cin>>n)
    {
        cout<<n*n<<endl;
    }
}