#include<bits/stdc++.h>
using namespace std;

char r[] = {74, 105, 97, 111, 122, 104, 117, 86, 53, 33};

int main(void)
{
    cout<<r<<endl;
    // system("pause");
}