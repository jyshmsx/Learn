#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;

int r[3];
int t;

void swap(void)
{
	sort(r , r + 3 ); 
}

int main(void)
{
	cin>>t;
	
	while(t--)
	{
		cin>>r[0]>>r[1]>>r[2];
		
		swap(); 
		
		cout<<r[0]<<":"<<r[1]<<":"<<r[2]<<endl;
	}
}


