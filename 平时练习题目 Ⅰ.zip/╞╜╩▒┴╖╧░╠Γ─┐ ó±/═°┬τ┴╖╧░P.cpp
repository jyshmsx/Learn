#include<stdio.h>
#include<iostream>
using namespace std;

int n; 
double c; 

int main (void)
{
	cin>>n;
	
	while(n--)
	{
		
		cin>>c;
		
		if ( c >= 60 && c <= 100)
			cout<<"YES"<<endl;
		else if ( c >= 0 && c < 60)
			cout<<"NO"<<endl;
		else
			cout<<"ERROR"<<endl;
	}
	
	return 0;
}
