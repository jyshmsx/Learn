#include<iostream>
using namespace std;

bool cmp(int);

int n, a, a2, c;

int main(void)
{
	cin>>n;
	
	while(n--)
	{
		cin>>a;
		
		c = 0;
		
		a2 = a / 2;
		
			
		for(int x = 3; x <= a2; x += 2)
		{
			if( cmp(x) )
			{
				int y = a - x;
				if( cmp(y) )
				{
					c++;
				}	
			}
		}
		
		cout<<c<<endl;
		
	}
}

bool cmp (int x)
{
	if( x % 2 == 0 && x != 2) 
		return 0;    
	  
	
  	for(int y = 1; y <= x; y += 2)
	{	
       	if( x % y == 0 && y != 1 && y != x)
       	{
           	return 0;
       	}
   	}
   	
   	return 1;
}

