#include<iostream>
#include<string.h>
using namespace std;

int n, m;
int r[101], s[5];

int main(void)
{
    cin>>n;

    while(n--)
    {
        memset(r, 0, sizeof(r));
        memset(s, 0, sizeof(s));
        cin>>m;

        for(int x = 0; x < m; x++) //�������ֵ
        {
            cin>>r[x];
        }

                                   // ����ƽ��ֵ
        for(int x = 0; x < m; x++)
        {
            s[0] += r[x];
        }

        s[0] = s[0] / m;

        s[2] = r[0];
        for(int x = 0; x < m; x++)
        {
            if(r[x] > s[1])
                s[1] = r[x];
            if(r[x] < s[2])
                s[2] = r[x];
            if(r[x] < s[0])
                s[3]++;
            if(r[x] >= s[0])
                s[4]++;
        }

        cout<<s[0]<<":"<<s[1]<<","<<s[2]<<":"<<s[3]<<","<<s[4]<<endl;


    }
}
