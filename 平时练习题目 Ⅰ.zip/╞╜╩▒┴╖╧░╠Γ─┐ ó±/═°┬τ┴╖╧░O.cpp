#include<iostream>
using namespace std;

struct man
{
	char name[25];
	int ach;
}n[105];

int t, MAX, MIN, ma, mi;

int main (void)
{
	MAX = 0; MIN = 0;
	
	cin>>t;
	for(int x = 0; x < t; x++)
	{
		cin>>n[x].name>>n[x].ach;
	}
	
	for(int x = 0, MIN = n[0].ach ; x < t; x++)
	{
		if(n[x].ach > MAX)
		{
			MAX = n[x].ach;
			ma = x;
		}
		if(n[x].ach < MIN)
		{
			MIN = n[x].ach;
			mi = x;
		}
	}
	
	cout<<n[ma].name<<" "<<n[ma].ach<<endl
		<<n[mi].name<<" "<<n[mi].ach<<endl;
	
	
	return 0;
}
