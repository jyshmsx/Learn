#include<iostream>
using namespace std;

int n, a, b, r[101], r1[101];

int main(void)
{
	cin>>n;
	
	while(n--)
	{
		cin>>a>>b;
		
		for(int x = 0; x < a; x++)
		{
			cin>>r[x];
		}
		
		for(int x = 0; x < a - b; x++)
		{
			r1[x] = r[x];
		}
		
		for(int x = a - b, y = 0; x < a; x++, y++)
		{
			r[y] = r[x];
		}
		
		for(int x = b, y = 0 ; x < a; x++, y++)
		{
			r[x] = r1[y];
		}
		
		for(int x = 0; x < a; x++)
		{
			cout<<r[x]<<":";
		}
		cout<<endl;
	}
 } 
