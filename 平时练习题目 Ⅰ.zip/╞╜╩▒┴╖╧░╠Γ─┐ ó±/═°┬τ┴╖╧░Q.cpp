#include<iostream>
using namespace std;

int t, n;

int main(void)
{
	cin>>t;
	
	while(t--)
	{
		cin>>n;
		int i = n ;
		cout<<n;
		for(n += i; n <= 100; n += i)
		{
			cout<<" "<<n;
		}
		cout<<endl;
	}
}
