#include<iostream>
#include<cmath>
#include<stdio.h> 
using namespace std;

int n;
double a, b, c;
double x1, x2;

int main(void)
{
	cin>>n;
	
	while(n--)
	{
		cin>>a>>b>>c;
		
		x1 = ( -b + sqrt(b * b - 4 * a * c) ) / (2 * a);
		x2 =  ( -b - sqrt(b * b - 4 * a * c) ) / (2 * a);
		
		printf("%.2lf %.2lf\n", x1, x2);
	}
}
