#include<iostream>
using namespace std;

char r[20];
int m;



int main(void)
{
	while(cin>>r>>m)
	{
		for(int x = 0; x < m; x++)
		{
			cout<<r[x];
		}
		cout<<endl;
	}
	return 0;
}
