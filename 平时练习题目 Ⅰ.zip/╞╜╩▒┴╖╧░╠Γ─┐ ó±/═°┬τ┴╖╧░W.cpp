#include<iostream>
using namespace std;
int x = 1, z;

int t;

int xunzhao(int x)
{
	if( x % 2 == 0 && x != 2) 
		return 0;    
	  
	  
  	for(int y = 1; y <= x; y++)
	{	
       	if( x % y == 0 && y != 1 && y != x)
       	{
           	return 0;
           	break;
       	}
   	}

    return x;
}

int main(void)
{
    cin>>t;
    while(t--)
    {
    	cin>>x; 
        z = 0;
        z = xunzhao(x);
        if(z != 0)
            cout<<"YES"<<endl;
        if(z == 0)
        	cout<<"NO"<<endl;
	}
}

