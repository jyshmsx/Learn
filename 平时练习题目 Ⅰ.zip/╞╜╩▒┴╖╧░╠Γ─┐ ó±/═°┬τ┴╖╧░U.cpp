#include<iostream>
using namespace std;

int t, a, b;  //tΪѭ��������aΪ������������ 

int main (void)
{
	cin>>t;
	
	while( t-- )
	{
		cin>>a;
	
		for( int x = 1; x <= a; x++)
		{
			for(int y = 1 ; y < a + x ; y++ )
			{
				if( y > a - x && y < a)
				{	
					cout<<"*";
				}
				else if( y > a - x && y >= a)
				{	
					cout<<"*";
				}	
				else 
					cout<<" ";       
			}
			cout<<endl;
		}
				
			
	}
	
	return 0;
}
