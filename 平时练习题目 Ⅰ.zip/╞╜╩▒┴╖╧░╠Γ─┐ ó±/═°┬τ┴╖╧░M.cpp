#include<iostream>
using namespace std;

int t;
unsigned int r[1000];
void func(void);


int main(void)
{
	cin>>t;
	
	while(t--)
	{
		for(int x = 0; x < 10; x++)
		{
			cin>>r[x];
		}
		
		func();
		
		for(int x = 0; x < 10 ; x++)
		{
			cout<<r[x]<<":";
		}
		cout<<endl;
	}
	
	return 0;
}

void func(void)
{
	unsigned int minn = r[0], maxn = 0;
	int lmi, lma;
	for(int x  = 0; x < 10; x++)	//Ѱ�����ֵ����Сֵ 
	{
		if(r[x] <= minn)
		{
			minn = r[x];
			lmi = x;
		}
		
		if(r[x] > maxn)
		{
			maxn = r[x];
			lma = x;
		}
	}
	
	minn = r[0];					//������Сֵ���һ��ֵ 
	r[0] = r[lmi];
	r[lmi] = minn;
	
	minn = r[9];					//�������ֵ�����һ���� 
	r[9] = r[lma];
	r[lma] = minn;
	
}
