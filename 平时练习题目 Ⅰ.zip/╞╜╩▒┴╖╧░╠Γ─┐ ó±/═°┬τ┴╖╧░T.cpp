#include<iostream>

using namespace std;

int n, m;

int  main(void)
{
	cin>>n;
	
	for(int x = 0; x < n; x++)
	{
		cin>>m;
		for(int y = 0; y < m; y++)
		{
			for(int z = 0; z <= y; z++)
			{
				cout<<"*";
			}
			cout<<endl;
		}
		
	}
}
