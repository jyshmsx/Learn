#include<stdio.h>
#include<iostream>
#include<string.h>
using namespace std;

char z[105], r[105];
int t, len;


int main (void)
{
	cin>>t;
	
	
	
	while(t--)
	{
		memset(z, '\0', sizeof(z));
		memset(r, '\0', sizeof(r));
		
		cin>>z;
		len = strlen(z);
		for(int x = 0, y = len - 1; x < len; x++, y--)
			r[x] = z[y];
			
		cout<<r<<endl;
	}
	
	return 0;
}
