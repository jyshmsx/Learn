#include<iostream>
using namespace std;

int t, a, b;  //tΪѭ��������aΪ������������ 

int main (void)
{
	cin>>t;
	
	while( t-- )
	{
		cin>>a;
		
		a = a/2 + 1;
		
		for( int x = 1; x < 2 * a ; x++)
		{
			if( x <= a )
				for(int y = 1; y < a + x; y++)
				{
					if( y > a - x )
						cout<<"*";
					else 
						cout<<" ";
				}
			else if ( x > a)
				for(int y = 1 ; y < 3 * a - x; y++)
				{
					if( y > x - a)
						cout<<"*";
					else 
						cout<<" ";
				}
			cout<<endl;
			
		}
				
			
	}
	
	return 0;
}
