#include<iostream>
#include<string.h>
#include<algorithm>
using namespace std;

bool cmp(int a, int b)
{
	return a > b;
}

int r[105];
int t, n;

int main (void)
{
	cin>>t;
	
	while(t--)
	{
		cin>>n;
		memset(r, 0, sizeof(r)); 
		for(int x = 0; x < n; x++)
		{
			cin>>r[x];
		}
		sort( r , r + n, cmp);
		
		
		for(int x = 0; x < n; x++)
			cout<<r[x]<<",";
		
		cout<<endl;
	}
}
