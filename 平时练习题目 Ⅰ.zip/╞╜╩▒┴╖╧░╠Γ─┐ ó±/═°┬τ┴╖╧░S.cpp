#include<iostream>
#include<cmath>
#include<stdio.h>
using namespace std;

int n;
double a , b, c;
double x1, x2, ix1, ix2;

void ssg(double , double , double);
void xsg(double , double , double);

int main(void)
{
	cin>>n;
	
	while(n--)
	{
		cin>>a>>b>>c;
		
		if( b * b - 4 * a * c >= 0)
			ssg(a , b, c);
		else 
			xsg(a , b, c);
	}
 } 
 
 void ssg(double a , double b, double c)
 {
 	x1 = ( -b + sqrt(b * b - 4 * a * c) ) / (2 * a);
	x2 =  ( -b - sqrt(b * b - 4 * a * c) ) / (2 * a);
	
	printf("%.2lf %.2lf\n", x1, x2);
	return;
 }
 
 void xsg(double a, double b, double c)
 {
 	x1 = -b / (2 * a);
 	
 	ix1 = sqrt( 4 * a * c - b * b) / (2 * a);
 	ix2 = -sqrt( 4 * a * c - b * b) / (2 * a);
 	
 	if(x1 == 0)
 	{
 		printf("%.2lfi %.2lfi\n", ix1, ix2);
	}
	else
	{
		printf("%.2lf+%.2lfi %.2lf%.2lfi\n", x1, ix1, x1, ix2);
	}
 	return;
 }
