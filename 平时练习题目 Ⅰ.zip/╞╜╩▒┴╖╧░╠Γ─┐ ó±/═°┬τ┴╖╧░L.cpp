#include<iostream>
#include<string.h>
using namespace std;

int t, r[41], a, b, z, l, L;

int main(void)
{
	cin>>t;
	
	while(t--)
	{
		cin>>a>>b;
		z =  0, l = 0 , L = 0;
		memset(r, 0, sizeof(r));
		
		
		
		for(int x = 0; x < a; x++)
		{
			cin>>r[x];
		}
		
		for(z = 0; z <= a; z++)
		{
			if( r[z] > b)
			{
				l = r[z];
				r[z] = b;
				break;		
			}
			else if( z == a )
			{
				l = r[z];
				r[a] = b;
				break;	
			}	
		}
		
		for(z++; z <= a; z++)
		{
			L = r[z];
			r[z] = l;
			l = L;
		}
		
		for( int x = 0 ; x <= a; x++)
		{
			cout<<r[x]<<":";
		}
		cout<<endl;
	}
}
